import os

os.system("aws s3 sync ./ s3://ibrahimfadel.com")
